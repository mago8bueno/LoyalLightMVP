"""API routers for the LoyalLightMVP application."""

from app.routers.status_check import router as status_check_router

__all__ = ["status_check_router"]