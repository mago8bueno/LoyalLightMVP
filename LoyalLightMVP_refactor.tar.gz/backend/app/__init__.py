"""
LoyalLightMVP Backend Application.

A FastAPI-based backend service for the LoyalLight MVP project.
Provides RESTful API endpoints for status check management with MongoDB integration.
"""

__version__ = "1.0.0"