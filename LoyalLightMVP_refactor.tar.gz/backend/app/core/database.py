"""
Database connection and configuration.

This module handles MongoDB connection setup using Motor (async MongoDB driver)
and provides database instance for use throughout the application.
"""

import logging
from typing import Optional

from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase

from app.core.config import settings

logger = logging.getLogger(__name__)


class DatabaseManager:
    """
    MongoDB database connection manager.
    
    Handles connection lifecycle and provides database instance access.
    Implements singleton pattern to ensure single connection per application.
    """
    
    def __init__(self) -> None:
        """Initialize database manager."""
        self.client: Optional[AsyncIOMotorClient] = None
        self.database: Optional[AsyncIOMotorDatabase] = None
    
    async def connect_to_mongo(self) -> None:
        """
        Create database connection.
        
        Establishes connection to MongoDB using settings from configuration.
        
        Raises:
            Exception: If connection to MongoDB fails
        """
        try:
            self.client = AsyncIOMotorClient(settings.mongo_url)
            self.database = self.client[settings.db_name]
            
            # Test the connection
            await self.client.admin.command('ping')
            
            logger.info(
                f"Successfully connected to MongoDB at {settings.mongo_url}"
            )
            
        except Exception as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            raise
    
    async def close_mongo_connection(self) -> None:
        """
        Close database connection.
        
        Properly closes the MongoDB connection when application shuts down.
        """
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")
    
    def get_database(self) -> AsyncIOMotorDatabase:
        """
        Get database instance.
        
        Returns:
            AsyncIOMotorDatabase: MongoDB database instance
            
        Raises:
            RuntimeError: If database connection hasn't been established
        """
        if self.database is None:
            raise RuntimeError(
                "Database connection not established. "
                "Call connect_to_mongo() first."
            )
        return self.database


# Global database manager instance
db_manager = DatabaseManager()


async def get_database() -> AsyncIOMotorDatabase:
    """
    Dependency function to get database instance.
    
    Used as FastAPI dependency to inject database into route handlers.
    
    Returns:
        AsyncIOMotorDatabase: MongoDB database instance
    """
    return db_manager.get_database()