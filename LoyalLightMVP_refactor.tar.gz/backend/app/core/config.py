"""
Application configuration settings.

This module contains all configuration settings for the LoyalLightMVP backend,
including database connections, environment variables, and application settings.
"""

import os
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from pydantic import BaseModel, Field


class Settings(BaseModel):
    """
    Application settings configuration.
    
    All settings are loaded from environment variables with sensible defaults.
    The .env file is automatically loaded from the backend root directory.
    """
    
    # Database Configuration
    mongo_url: str = Field(
        default="mongodb://localhost:27017",
        description="MongoDB connection URL"
    )
    
    db_name: str = Field(
        default="test_database",
        description="MongoDB database name"
    )
    
    # API Configuration
    api_prefix: str = Field(
        default="/api",
        description="API route prefix"
    )
    
    # CORS Configuration
    cors_origins: list[str] = Field(
        default=["*"],
        description="Allowed CORS origins"
    )
    
    # Application Settings
    app_name: str = Field(
        default="LoyalLightMVP API",
        description="Application name"
    )
    
    debug: bool = Field(
        default=False,
        description="Debug mode flag"
    )


def load_settings() -> Settings:
    """
    Load application settings.
    
    Loads the .env file from the backend root directory and returns
    a Settings instance with all configuration values.
    
    Returns:
        Settings: Configured application settings instance
    """
    # Load .env file from backend root directory
    root_dir = Path(__file__).parent.parent.parent
    env_path = root_dir / '.env'
    
    if env_path.exists():
        load_dotenv(env_path)
    
    # Load settings from environment variables
    return Settings(
        mongo_url=os.environ.get('MONGO_URL', 'mongodb://localhost:27017'),
        db_name=os.environ.get('DB_NAME', 'test_database'),
        debug=os.environ.get('DEBUG', 'false').lower() == 'true'
    )


# Global settings instance
settings = load_settings()