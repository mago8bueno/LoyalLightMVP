"""
LoyalLightMVP FastAPI Application.

Main application entry point with proper structure and configuration.
Maintains exact same API endpoints and behavior as original implementation
while providing clean, maintainable code organization.
"""

import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.core.database import db_manager
from app.routers import status_check_router


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """
    Application lifespan manager.
    
    Handles startup and shutdown events for the FastAPI application,
    including database connection management.
    
    Args:
        app: FastAPI application instance
        
    Yields:
        None: Control during application runtime
    """
    # Startup
    logger.info("Starting LoyalLightMVP API...")
    
    try:
        # Connect to database
        await db_manager.connect_to_mongo()
        logger.info("Database connection established")
        
        # Application is ready
        logger.info(f"API started successfully on {settings.api_prefix}")
        
        yield
        
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        raise
    
    finally:
        # Shutdown
        logger.info("Shutting down LoyalLightMVP API...")
        
        # Close database connection
        await db_manager.close_mongo_connection()
        
        logger.info("Application shutdown complete")


def create_application() -> FastAPI:
    """
    Create and configure FastAPI application.
    
    Sets up the FastAPI application with all necessary middleware,
    routes, and configuration. Maintains exact same API structure
    as original implementation.
    
    Returns:
        FastAPI: Configured application instance
    """
    # Create FastAPI application
    app = FastAPI(
        title=settings.app_name,
        version="1.0.0",
        description="A FastAPI-based backend service for LoyalLight MVP",
        lifespan=lifespan
    )
    
    # Add CORS middleware (exact same configuration as original)
    app.add_middleware(
        CORSMiddleware,
        allow_credentials=True,
        allow_origins=settings.cors_origins,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Include routers with API prefix (maintains exact same endpoints)
    app.include_router(
        status_check_router,
        prefix=settings.api_prefix
    )
    
    logger.info("FastAPI application configured successfully")
    
    return app


# Create application instance
app = create_application()


if __name__ == "__main__":
    """
    Direct execution entry point.
    
    Allows running the application directly with python -m app.main
    for development purposes.
    """
    import uvicorn
    
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8001,
        reload=settings.debug,
        log_level="info"
    )