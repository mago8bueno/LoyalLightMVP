"""Data models for the LoyalLightMVP application."""

from app.models.status_check import StatusCheck, StatusCheckCreate

__all__ = ["StatusCheck", "StatusCheckCreate"]