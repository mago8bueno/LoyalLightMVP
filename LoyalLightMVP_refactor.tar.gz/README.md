# LoyalLight MVP 🚀

> A modern FastAPI + React application with clean architecture, accessibility features, and subtle animations.

## ✨ Features

- **Backend**: FastAPI with modular architecture, type hints, and comprehensive error handling
- **Frontend**: React with modern components, accessibility (WCAG 2.1 AA), and smooth animations
- **Database**: MongoDB with async operations using Motor
- **Styling**: Tailwind CSS with custom animations and glassmorphism effects
- **Architecture**: Clean separation of concerns with proper folder structure

## 🏗️ Architecture

### Backend Structure
```
backend/
├── app/
│   ├── __init__.py              # Application package
│   ├── main.py                  # FastAPI application entry point
│   ├── core/
│   │   ├── __init__.py
│   │   ├── config.py            # Application settings
│   │   └── database.py          # MongoDB connection manager
│   ├── models/
│   │   ├── __init__.py
│   │   └── status_check.py      # Pydantic models
│   ├── routers/
│   │   ├── __init__.py
│   │   └── status_check.py      # API endpoints
│   └── services/
│       ├── __init__.py
│       └── status_check_service.py  # Business logic
├── requirements.txt             # Python dependencies
└── server.py                    # Legacy compatibility entry point
```

### Frontend Structure
```
frontend/
├── src/
│   ├── components/
│   │   ├── Header.js            # Main header component
│   │   └── Header.css           # Header styles with animations
│   ├── pages/
│   │   ├── Home.js              # Home page component
│   │   └── Home.css             # Home page styles
│   ├── services/
│   │   └── apiService.js        # Centralized API communications
│   ├── utils/
│   │   └── constants.js         # Application constants
│   ├── App.js                   # Main application component
│   ├── App.css                  # Global application styles
│   ├── index.js                 # React entry point
│   └── index.css                # Global styles + Tailwind
├── public/
│   └── index.html               # HTML template
├── package.json                 # Dependencies and scripts
├── tailwind.config.js           # Tailwind configuration
├── postcss.config.js            # PostCSS configuration
└── craco.config.js              # React build configuration
```

## 🚀 Quick Start

### Prerequisites

- Python 3.11+
- Node.js 16+
- MongoDB (local or remote)
- Yarn package manager

### Installation & Setup

1. **Clone and setup the project:**
   ```bash
   # Navigate to project directory
   cd LoyalLightMVP
   
   # Run the automated setup script
   ./launch_mvp.sh
   ```

2. **Manual setup (alternative):**

   **Backend Setup:**
   ```bash
   cd backend
   pip install -r requirements.txt
   
   # Configure environment variables
   cp .env.example .env
   # Edit .env with your MongoDB connection details
   
   # Start the backend server
   uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload
   ```

   **Frontend Setup:**
   ```bash
   cd frontend
   yarn install
   
   # Configure environment variables
   cp .env.example .env
   # Edit .env with your backend URL
   
   # Start the frontend development server
   yarn start
   ```

### Environment Configuration

**Backend (.env):**
```env
MONGO_URL=mongodb://localhost:27017
DB_NAME=loyallight_mvp
DEBUG=false
```

**Frontend (.env):**
```env
REACT_APP_BACKEND_URL=http://localhost:8001
WDS_SOCKET_PORT=3000
```

## 📚 API Documentation

### Endpoints

- **GET `/api/`** - Health check endpoint
  - Response: `{"message": "Hello World"}`

- **POST `/api/status`** - Create a status check
  - Body: `{"client_name": "string"}`
  - Response: `{"id": "uuid", "client_name": "string", "timestamp": "datetime"}`

- **GET `/api/status`** - Get all status checks
  - Response: `[{"id": "uuid", "client_name": "string", "timestamp": "datetime"}]`

### Example Usage

```bash
# Health check
curl http://localhost:8001/api/

# Create status check
curl -X POST http://localhost:8001/api/status \
  -H "Content-Type: application/json" \
  -d '{"client_name": "Acme Corp"}'

# Get all status checks
curl http://localhost:8001/api/status
```

## 🎨 Frontend Features

### Animations
- **Fade-in effects** for page load
- **Smooth hover transitions** on interactive elements
- **Subtle scaling** for buttons and cards
- **Slide-up animations** for text elements
- **Loading spinners** with smooth rotation

### Accessibility (WCAG 2.1 AA Compliant)
- **Keyboard navigation** support
- **Focus indicators** for all interactive elements
- **ARIA labels** and roles
- **Screen reader** compatibility
- **High contrast mode** support
- **Reduced motion** respect for users with motion sensitivity

### Responsive Design
- **Mobile-first** approach
- **Breakpoints** at 768px, 1024px, and 1200px
- **Flexible layouts** that adapt to screen size
- **Touch-friendly** interface elements

## 🛠️ Development

### Code Quality Standards

**Backend (Python):**
- **PEP 8** compliance
- **Type hints** throughout
- **Google-style docstrings**
- **Comprehensive error handling**
- **Modular architecture**

**Frontend (JavaScript):**
- **Prettier** formatting (2-space indentation)
- **ESLint** configuration
- **Component-based architecture**
- **Modern React patterns**
- **Accessibility best practices**

### Available Scripts

**Backend:**
```bash
# Run with auto-reload
uvicorn app.main:app --reload

# Run tests
pytest

# Code formatting
black .
isort .
flake8 .
```

**Frontend:**
```bash
# Development server
yarn start

# Production build
yarn build

# Run tests
yarn test

# Code formatting
yarn prettier --write .
```

## 🔧 Technology Stack

### Backend
- **FastAPI** - Modern Python web framework
- **Motor** - Async MongoDB driver
- **Pydantic** - Data validation and serialization
- **Uvicorn** - ASGI server
- **Dotenv** - Environment variable management

### Frontend
- **React 19** - UI library
- **React Router** - Client-side routing
- **Axios** - HTTP client
- **Tailwind CSS** - Utility-first CSS framework
- **PostCSS** - CSS processing
- **CRACO** - Create React App configuration

### Database
- **MongoDB** - NoSQL document database
- **UUID** - Primary key strategy (no ObjectId)

## 📦 Deployment

### Production Build

```bash
# Backend
cd backend
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8001

# Frontend
cd frontend
yarn build
# Serve the build directory with your preferred web server
```

### Docker Support (Optional)

```dockerfile
# Example Dockerfile for backend
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8001"]
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- **Emergent Platform** - Hosting and development environment
- **FastAPI Community** - Excellent framework and documentation
- **React Team** - Powerful UI library
- **Tailwind CSS** - Beautiful utility-first CSS framework

---

**Built with ❤️ by the LoyalLight Team**

For support or questions, please open an issue in the repository.