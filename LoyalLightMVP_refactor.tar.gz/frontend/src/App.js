/**
 * Main App Component
 * 
 * Root component for the LoyalLight MVP application.
 * Includes routing, error boundaries, and accessibility features.
 * Refactored for better maintainability and modern React patterns.
 */

import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import './App.css';

/**
 * Error Boundary Component for handling React errors gracefully
 */
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('React Error Boundary caught an error:', error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div 
          className="error-boundary"
          role="alert"
          aria-live="assertive"
        >
          <div className="error-content">
            <h1>Oops! Something went wrong</h1>
            <p>
              We're sorry, but an unexpected error occurred. 
              Please refresh the page and try again.
            </p>
            <button
              onClick={() => window.location.reload()}
              className="error-reload-button"
              type="button"
            >
              Reload Page
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

/**
 * Main Application Component
 */
function App() {
  return (
    <ErrorBoundary>
      <div 
        className="app"
        role="application"
        aria-label="LoyalLight MVP Application"
      >
        <BrowserRouter>
          <Routes>
            <Route 
              path="/" 
              element={<Home />}
            />
            {/* Future routes can be added here */}
            <Route 
              path="*" 
              element={
                <div 
                  className="not-found"
                  role="main"
                  aria-label="Page not found"
                >
                  <h1>404 - Page Not Found</h1>
                  <p>The page you're looking for doesn't exist.</p>
                </div>
              } 
            />
          </Routes>
        </BrowserRouter>
      </div>
    </ErrorBoundary>
  );
}

export default App;